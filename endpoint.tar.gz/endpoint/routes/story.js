var express = require('express');
var router = express.Router();
const MongoClient = require('mongodb').MongoClient;
const assert = require('assert')


/* GET users listing. */
router.get('/', function(req, res, next) {
  const url = "mongodb://localhost:27017/writingprompts";
MongoClient.connect(url,function(err,database){
if(err) throw err;
const localDB = database.db("writingprompts");
var recordCount;
totalRecords = localDB.collection("stories").count(function(e,count){
  randomIndex = Math.floor((Math.random())*count+0);
  var x = localDB.collection("stories").find().limit(-1).skip(randomIndex).next(function(e,x){
    res.send(x)
  });
  

});

});

});

module.exports = router;
