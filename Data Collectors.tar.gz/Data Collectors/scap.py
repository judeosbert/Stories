import requests
import json
from pprint import pprint
import os
import random
import datetime
from pymongo import MongoClient
import sys
client = MongoClient()

db = client['writingprompts']
index = db.index
# db["index"].create_index([("name","text")],unique=True)

userHomeDirectory = os.path.expanduser("~");
afterNameFile = userHomeDirectory+"/.scrapperData/afterName"
storiesFile = userHomeDirectory+"/.scrapperData/stories"
logFile = userHomeDirectory+"/.scrapperData/log"
class Story:
    def __init__(self,name,url,title,num_comments):
        self.name = name
        self.url  = url
        self.title = title
        self.num_comments = num_comments
        self.collected = False
        self.last_refreshed = ''

    def getDetails(self):
        return {'name':self.name,
                'title':self.title,
                'url':self.url,
                'num_comments':self.num_comments,
                'collected':self.collected,
                'last_visited':self.last_refreshed}
#---------------------------------------------------------
afterName = ''
logfile  = open(logFile,"a")
file = open(afterNameFile,"r")
afterName = file.readline();
try:
	logfile.write("AfterName was found as->"+afterName+"\n")
except Exception as e:
	print "The query has exhausted.Try few days later"
	sys.exit(0)
print "AfterName was found as->"+afterName
file.close()

headers = {
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36',
    'From': 'https://www.reddit.com',
    'Connection':'close'
}
url = ''
if afterName == '':
    url = "https://www.reddit.com/r/WritingPrompts/top.json"
else:
    url = "https://www.reddit.com/r/WritingPrompts/top.json?after="+afterName

page = requests.get(url,headers = headers)
loadedJSON = page.json()
children = loadedJSON["data"]["children"]
writeBuffer = list();
for child in children:
    story = Story(child["data"]["name"],child["data"]["url"],child["data"]["title"],child["data"]["num_comments"])
    storyDetails = story.getDetails()
    print "New story ",storyDetails
    writeBuffer.append(storyDetails)
try:
	result = index.insert_many(writeBuffer)
except Exception as e:
	print e , "inserting multiple records function"
	sys.exit(0)
print ('Multiple posts :{0}'.format(result.inserted_ids))

afterName = loadedJSON["data"]["after"]
try:
	print "Writing afterName to file: Aftername:"+afterName
except Exception as e:
	print "The query has exhausted.Try few days later"
	sys.exit(0)
file = open(afterNameFile,"w")
file.write(afterName)
file.close()
logfile.write("Done......\n")
print "Done......"

logfile.write("Script ran at "+datetime.datetime.now().strftime("%A, %d. %B %Y %I:%M%p")+"\n")
logfile.close()
