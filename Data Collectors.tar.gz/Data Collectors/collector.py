import requests
import os
import pymongo
from pymongo import MongoClient
from pprint import pprint
import json
import datetime
client = MongoClient()
userHomeDirectory = os.path.expanduser("~")
db = client["writingprompts"]
indexs = db.index
#On hold for now.
# shortStory = db.shortStory
# mediumStory = db.mediumStory
# longStory = db.longStory
stories = db.stories
logFile = userHomeDirectory+"/.scrapperData/Colllectorlog"
logfile = open(logFile,"a")

def refineAndFindTitle(title):
    type,refinedTitle = "",""
    type = title[0:4]
    type = type.replace("[","").replace("]","")
    refinedTitle = title[4:].strip()
    return refinedTitle,type

def decideCategory(length):
    if length <= 500:
        return "short"
    elif length > 501 and length <= 1000:
        return "medium"
    else:
        return "long"



class Post:
    def __init__(self,name,title,type,author,permalink,body,category):
        self.name = name 
        self.title = title
        self.body = body
        self.author = author
        self.permalink = permalink
        self.type = type
        self.category = category
        
    def export(self):
        return {"_id":self.name,
                "title":self.title,
                "body":self.body,
                "author":self.author,
                "permalink":self.permalink,
                "type":self.type,
                "category":self.category
                }

headers = {
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36',
    'From': 'https://www.reddit.com',
    'Connection':'close'  # This is another valid field
}
for index in indexs.find({"collected":False}):
    logfile.write(index["name"])
    logfile.write("\n")
    if(index["num_comments"] == 1):
        continue
    maxStories = min(index["num_comments"],5)+1 #First one is the robot comment
    url = index["url"]+"popular.json?limit="+str(maxStories)
    #print "URL ",url
    page = requests.get(url,headers = headers)
    loadedJSON = page.json()
    loadedJSON = loadedJSON[1]["data"]["children"]
    for story_number in range(1,len(loadedJSON)):
        if(story_number == len(loadedJSON)-1):
            continue
        post = loadedJSON[story_number]["data"]
        title,type = refineAndFindTitle(index["title"])
        #print "story Number",story_number
        permalink = "https://www.reddit.com"+post["permalink"]
        category = decideCategory(len(post["body"]))
        entry = Post(post["name"],title,type,post["author"],permalink,post["body"],category)
	#Changed from post["body_html"] to post["body"] because of div and class attributes in the records
        try:
            # if category == "short":
            #     shortStory.insert_one(entry.export())
            # elif category == "medium":
            #     mediumStory.insert_one(entry.export())
            # else:
            #     longStory.insert_one(entry.export())
            stories.insert_one(entry.export())
            logfile.write("Story Inserted\n");
            logfile.write( "-----------------------------------------------------------------\n")
        except pymongo.errors.DuplicateKeyError: # Check the error type.
            logfile.write("Duplicate Story. Skipping\n")
            logfile.write("-----------------------------------------------------------------\n")
    db.index.update_one({
        "_id":index["_id"]},{"$set":{
            "collected":True
        }},upsert=False)
logfile.write("Script ran at "+datetime.datetime.now().strftime("%A, %d. %B %Y %I:%M%p")+"\n")
logfile.close()



            
